# h4ci_garage

Aperçu : https://prnt.sc/zhranv

[INSTALLATION]

1) Importer h4ci_garage.sql dans votre base de données

2) Ajouter à votre server.cfg :

```
start h4ci_garage
```

[A SAVOIR]

* Pour modifier les prix de la fourrière rendez-vous dans le ``config.lua`` et vous modifier le ``garagepublic.sousfourriere``


* Pour ajouter des garages ou fourrière c'est dans le ``config.lua`` 


https://discord.gg/VhNxmgu
